import AdminLayout from './AdminLayout.vue';

export { AdminLayout };
