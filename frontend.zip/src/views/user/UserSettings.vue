<template>
    <SettingsView />
</template>

<script setup>
    import SettingsView from '@/views/settings/SettingsView.vue';
</script>
