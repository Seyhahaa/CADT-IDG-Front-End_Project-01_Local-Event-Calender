<template>
    <footer>
        <div class="w-100 dark-bg2 position-relative">
            <div class="footer-cont-wrap w-100">
                <div class="container">
                    <div
                        class="footer-cont-inner d-flex flex-wrap align-items-center justify-content-between"
                    >
                        <div class="footer-cont-info">
                            <ul class="mb-0 list-unstyled d-inline-flex">
                                <li>
                                    <i class="rounded thm-bg fas fa-phone"></i>ផ្តល់ជំនួយ: +01
                                    5426 24400
                                </li>
                                <li>
                                    <i class="rounded thm-bg fas fa-envelope"></i>អ៊ីម៉េល:
                                    <a href="javascript:void(0);" title="">event@wegokh.com</a>
                                </li>
                            </ul>
                        </div>
                        <div class="footer-cont-btn">
                            <a class="thm-btn rounded" href="about.html" title="">អំពីពួកយើង</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Contact Wrap -->
            <div class="footer-data w-100">
                <div class="container res-row">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-3">
                            <div class="widget w-100">
                                <div class="logo">
                                    <h1 class="mb-0">
                                        <a href="index.html" title="Home"
                                            ><img
                                                class="img-fluid"
                                                src="assets/images/logo.png"
                                                alt="Logo"
                                                srcset="assets/images/retina-logo.png"
                                        /></a>
                                    </h1>
                                </div>
                                <p class="mb-0">
                                    គេហទំព័រនេះគឺជាវេទិកាមួយដែលត្រូវបានរចនាឡើងដើម្បីជួយបុគ្គលនិងអង្គការនានាឱ្យរកឃើញ
                                    ការផ្សព្វផ្សាយនិងចូលរួមព្រឹត្តិការណ៍នានា។ គេហទំព័រទាំងនេះជាធម្មតាមានបញ្ជីដ៏ទូលំទូលាយនៃព្រឹត្តិការណ៍នាពេលខាងមុខដូចជាសន្និសីទការប្រគំតន្ត្រីពិធីបុណ្យសិក្ខាសាលាការជួបជុំនិងការជួបជុំសង្គម។ ដែលអ្នកប្រើប្រាស់អាចស្វែងរកត្រងនិងស្វែងរកព្រឹត្តិការណ៍តាមប្រភេទទីតាំងកាលបរិច្ឆេទនិងលក្ខណៈវិនិច្ឆ័យផ្សេងទៀត។
                                </p>
                                
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-5">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-6">
                                    <div class="widget w-100">
                                        <h3>តំណរភ្ជាប់សំខាន់ៗ</h3>
                                        <ul class="mb-5 list-unstyled w-100">
                                            <li>
                                                <a href="javascript:void(0);" title="">ទំនាក់ទំនងមកខ្ញុំ</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title="">ពត៌មានរបសកម្មវិធី</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >ក្រុមការងាររបស់់ខ្ញុំ</a
                                                >
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title="">សេវាកម្មរបស់យើង</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >មតិរបស់អ្នកប្រើប្រាស់</a
                                                >
                                            </li>
                                        </ul>
                                    <div class="social-links d-inline-block">
                                    <a href="javascript:void(0);" title="Facebook" target="_blank"
                                        ><i class="fab fa-facebook-f"></i
                                    ></a>
                                    <a href="javascript:void(0);" title="Twitter" target="_blank"
                                        ><i class="fab fa-twitter"></i
                                    ></a>
                                    <a
                                        href="javascript:void(0);"
                                        title="Google Plus"
                                        target="_blank"
                                        ><i class="fab fa-google-plus-g"></i
                                    ></a>
                                    <a href="javascript:void(0);" title="Linkedin" target="_blank"
                                        ><i class="fab fa-linkedin-in"></i
                                    ></a>
                                </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-6">
                                    <div class="widget w-100">
                                        <h3>ប្រភេទកំពុងចាប់អារម្មណ៍</h3>
                                        <ul class="mb-0 list-unstyled w-100">
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >ពិពណ៌ស្វែងរកការងារ</a
                                                >
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >សិក្ខាសាលា</a
                                                >
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >កិច្ចពិភាក្សារ</a
                                                >
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title=""
                                                    >ការតាំងពិពណ៌</a
                                                >
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" title="">កម្មវិធីសង្គមផ្សេងៗ</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="widget w-100">
                                <h3>វិចិត្រសាល</h3>
                                <ul class="gallery-list mb-0 list-unstyled d-flex flex-wrap">
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid object-cover h-[7.2rem] w-100"
                                                src="https://images.unsplash.com/photo-1523698120758-030a38a90d16?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fEV4aGliaXRpb258ZW58MHx8MHx8fDA%3D"
                                                alt="Gallery Image 1"
                                        /></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid object-cover h-[7.2rem] w-100"
                                                src="https://images.unsplash.com/photo-1573055418049-c8e0b7e3403b?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDk0fHx8ZW58MHx8fHx8"
                                                alt="Gallery Image 2"
                                        /></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid object-cover h-[7.2rem] w-100"
                                                src="https://media.istockphoto.com/id/1654533743/photo/panel-discussion-asian-business-person-discussion-on-stage-during-business-conference-seminar.webp?a=1&s=612x612&w=0&k=20&c=v0_ZpdM-_aPPn9at00PiW_XNr4O-ugjpslot4jS3CKY="
                                                alt="Gallery Image 3"
                                        /></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid object-cover h-[7.2rem] w-100"
                                                src="https://images.unsplash.com/photo-1472653816316-3ad6f10a6592?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fEV2ZW50fGVufDB8fDB8fHww"
                                                alt="Gallery Image 4"
                                        /></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid object-cover h-[7.2rem] w-100"
                                                src="https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fEV2ZW50fGVufDB8fDB8fHww"
                                                alt="Gallery Image 5"
                                        /></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid w-100 object-cover h-[7.2rem]"
                                                src="https://media.istockphoto.com/id/2094337676/photo/diverse-team-working-together-in-modern-co-working-space.webp?a=1&b=1&s=612x612&w=0&k=20&c=FbH7i1I3oCXoRfZKFvGj3jMXnsljD8mPmDmvY4IxQuA="
                                                alt="Gallery Image 6"
                                        /></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Data -->
        </div>
    </footer>
    <!-- Footer -->
    <div class="copyright text-center w-100">
        <div class="container">
            <p class="mb-0">
                &copy; 2020 <a href="" title="">WegoKh</a> — Event & 
                Social Opportunity. Developed by
                <a
                    href=""
                    title="Jthemes"
                    target="_blank"
                    >Group-Rean</a
                >
            </p>
        </div>
    </div>
    <!-- Copyright -->
</template>
