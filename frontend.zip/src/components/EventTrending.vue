<template>
    <section>
        <div class="w-100 pt-140 pb-140 gray-layer2 opc85 position-relative">
            <img
                class="lf-bt-img img-fluid position-absolute"
                src="assets/images/icon-img.png"
                alt="Icon Image"
            />
            <div class="fixed-bg" style="background-image: url(assets/images/parallax1.jpg)"></div>
            <div class="container">
                <div class="sec-title text-center w-100">
                    <span class="d-block thm-clr">Featured Cities</span>
                    <h2 class="mb-0">Explore Trending Category</h2>
                </div>
                <!-- Sec Title -->
                <div class="city-wrap">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-6">
                            <div class="city-box brd-rd5 overflow-hidden w-100">
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/city-img1-1.jpg"
                                    alt="City Image 1"
                                />
                                <div class="city-info position-absolute">
                                    <div class="city-info-inner">
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title="">England</a>
                                        </h3>
                                        <span class="d-block">( 20, available City Events )</span>
                                    </div>
                                    <a class="thm-btn" href="place-listing.html" title=""
                                        >Discover Now</a
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-6">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-6">
                                    <div class="city-box brd-rd5 overflow-hidden w-100">
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/city-img1-2.jpg"
                                            alt="City Image 2"
                                        />
                                        <div class="city-info position-absolute">
                                            <div class="city-info-inner">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title="">Canada</a>
                                                </h3>
                                                <span class="d-block"
                                                    >( 20, available City Events )</span
                                                >
                                            </div>
                                            <a class="thm-btn" href="place-listing.html" title=""
                                                >Discover Now</a
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-6">
                                    <div class="city-box brd-rd5 overflow-hidden w-100">
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/city-img1-3.jpg"
                                            alt="City Image 3"
                                        />
                                        <div class="city-info position-absolute">
                                            <div class="city-info-inner">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title="">India</a>
                                                </h3>
                                                <span class="d-block"
                                                    >( 20, available City Events )</span
                                                >
                                            </div>
                                            <a class="thm-btn" href="place-listing.html" title=""
                                                >Discover Now</a
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-lg-12">
                                    <div class="city-box brd-rd5 overflow-hidden w-100">
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/city-img1-4.jpg"
                                            alt="City Image 4"
                                        />
                                        <div class="city-info position-absolute">
                                            <div class="city-info-inner">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >Australia</a
                                                    >
                                                </h3>
                                                <span class="d-block"
                                                    >( 20, available City Events )</span
                                                >
                                            </div>
                                            <a class="thm-btn" href="place-listing.html" title=""
                                                >Discover Now</a
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Category Wrap -->
            </div>
        </div>
    </section>
</template>
