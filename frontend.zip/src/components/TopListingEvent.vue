<template>
    <section>
        <div class="w-100 pt-140 pb-140 position-relative">
            <div class="container">
                <div class="sec-title text-center w-100">
                    <span class="d-block thm-clr">Restaurants Event</span>
                    <h2 class="mb-0">Top Listing Events</h2>
                </div>
                <!-- Sec Title -->
                <div class="top-list-post-wrap position-relative w-100">
                    <div class="top-list-img position-relative">
                        <span class="rounded-pill position-absolute">Now Closed</span>
                        <img
                            class="img-fluid rounded"
                            src="assets/images/resources/top-list-image.jpg"
                            alt="Top List Image"
                        />
                    </div>
                    <div class="top-list-info position-absolute rounded">
                        <span class="d-block"
                            ><i class="fas fa-ticket-alt"></i>Ticket: $25 - $35</span
                        >
                        <h3 class="mb-0">
                            <a href="place-layout-detail.html" title=""
                                >Explore on-going and Upcoming Events</a
                            >
                        </h3>
                        <p class="mb-0">
                            Luxury hotel in the heart of BloomsburyLuxury hotel in the heart of
                            Bloomsbury..
                        </p>
                        <ul class="post-meta mb-0 list-unstyled w-100">
                            <li>
                                <i class="fas fa-map-marker-alt rounded-circle"></i>95 South Park
                                Avenue
                            </li>
                            <li><i class="fas fa-phone rounded-circle"></i>+61 2 8236 9200</li>
                        </ul>
                        <a class="thm-btn" href="place-layout-detail.html" title="">Discover Now</a>
                    </div>
                </div>
                <!-- Top List Post Wrap -->
            </div>
        </div>
    </section>
</template>
