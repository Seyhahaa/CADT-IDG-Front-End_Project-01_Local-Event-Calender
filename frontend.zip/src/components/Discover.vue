<template>
<section>
                <div class="w-100 pt-140 pb-110 position-relative">
                    <div class="fixed-bg bg-norepeate" style="background-image: url(assets/images/how-we-work-bg.png);"></div>
                    <div class="container">
                        <div class="sec-title text-center w-100">
                            <span class="d-block thm-clr">Discover & connect with great local businesses</span>
                            <h2 class="mb-0">See How it Works</h2>
                        </div><!-- Sec Title -->
                        <div class="how-work-wrap res-row text-center w-100">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-4">
                                    <div class="how-work-box w-100">
                                        <span class="rounded-circle d-inline-block"><img class="img-fluid" src="assets/images/resources/how-work-icon1.png" alt="How It Works Icon 1"></span>
                                        <div class="how-work-inner w-100">
                                            <h3 class="mb-0">Choose what to Do</h3>
                                            <p class="mb-0">Luxury hotel in the heart of BloomsburyLuxury hotel in the heart of Bloomsbury..</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4">
                                    <div class="how-work-box w-100">
                                        <span class="rounded-circle d-inline-block"><img class="img-fluid" src="assets/images/resources/how-work-icon2.png" alt="How It Works Icon 2"></span>
                                        <div class="how-work-inner w-100">
                                            <h3 class="mb-0">Find What You Want</h3>
                                            <p class="mb-0">Luxury hotel in the heart of BloomsburyLuxury hotel in the heart of Bloomsbury..</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4">
                                    <div class="how-work-box w-100">
                                        <span class="rounded-circle d-inline-block"><img class="img-fluid" src="assets/images/resources/how-work-icon3.png" alt="How It Works Icon 3"></span>
                                        <div class="how-work-inner w-100">
                                            <h3 class="mb-0">Amazing Places</h3>
                                            <p class="mb-0">Luxury hotel in the heart of BloomsburyLuxury hotel in the heart of Bloomsbury..</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Services Wrap -->
                    </div>
                </div>
            </section>
</template>
