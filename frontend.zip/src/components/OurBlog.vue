<template>
    <section>
        <div class="w-100 pt-180 pb-110 black-layer opc45 position-relative">
            <div class="fixed-bg" style="background-image: url(assets/images/pg-tp-bg.jpg)"></div>
            <div class="container">
                <div class="pg-tp-wrp text-center w-100">
                    <h1 class="mb-0">Blog & News</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="index.html" title="Home">Home</a>
                        </li>
                        <li class="breadcrumb-item active">About us</li>
                    </ol>
                </div>
                <!-- Page Top Wrap -->
            </div>
        </div>
        <div class="w-100 pb-100 position-relative">
            <div class="container">
                <div class="sec-title text-center w-100">
                    <span class="d-block thm-clr">Browse the latest articles from our blog.</span>
                    <h2 class="mb-0">Tips & Articles</h2>
                </div>
                <!-- Sec Title -->
                <div class="blog-wrap res-row w-100">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="blog-post-box w-100">
                                <div class="blog-post-img overflow-hidden w-100">
                                    <a href="javascript:void(0);" title=""
                                        ><img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/blog-img1-1.jpg"
                                            alt="Blog Image 1"
                                    /></a>
                                </div>
                                <div class="blog-post-info w-100">
                                    <span class="post-date d-inline-block">11 June</span>
                                    <h3 class="mb-0">
                                        <a href="javascript:void(0);" title=""
                                            >Standard Post Format</a
                                        >
                                    </h3>
                                    <p class="mb-0">
                                        Qui nunc nobis videntur parum clari, sollemnes in futurum
                                        putamus parum claram legere.
                                    </p>
                                    <span class="post-auth d-inline-block"
                                        >Posted by
                                        <a href="javascript:void(0);" title="">Robin Miles</a></span
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="blog-post-box w-100">
                                <div class="blog-post-img overflow-hidden w-100">
                                    <a href="javascript:void(0);" title=""
                                        ><img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/blog-img1-2.jpg"
                                            alt="Blog Image 2"
                                    /></a>
                                </div>
                                <div class="blog-post-info w-100">
                                    <span class="post-date d-inline-block">11 June</span>
                                    <h3 class="mb-0">
                                        <a href="javascript:void(0);" title=""
                                            >Standard Post Format</a
                                        >
                                    </h3>
                                    <p class="mb-0">
                                        Qui nunc nobis videntur parum clari, sollemnes in futurum
                                        putamus parum claram legere.
                                    </p>
                                    <span class="post-auth d-inline-block"
                                        >Posted by
                                        <a href="javascript:void(0);" title="">Robin Miles</a></span
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="blog-post-box w-100">
                                <div class="blog-post-img overflow-hidden w-100">
                                    <a href="javascript:void(0);" title=""
                                        ><img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/blog-img1-3.jpg"
                                            alt="Blog Image 3"
                                    /></a>
                                </div>
                                <div class="blog-post-info w-100">
                                    <span class="post-date d-inline-block">11 June</span>
                                    <h3 class="mb-0">
                                        <a href="javascript:void(0);" title=""
                                            >Standard Post Format</a
                                        >
                                    </h3>
                                    <p class="mb-0">
                                        Qui nunc nobis videntur parum clari, sollemnes in futurum
                                        putamus parum claram legere.
                                    </p>
                                    <span class="post-auth d-inline-block"
                                        >Posted by
                                        <a href="javascript:void(0);" title="">Robin Miles</a></span
                                    >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Blog Wrap -->
            </div>
        </div>
    </section>
</template>
