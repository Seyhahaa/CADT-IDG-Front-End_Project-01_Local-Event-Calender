<template>
    <main>
        <section>
            <div class="w-100 pt-180 pb-110 black-layer opc45 position-relative">
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/pg-tp-bg.jpg)"
                ></div>
                <div class="container">
                    <div class="pg-tp-wrp text-center w-100">
                        <h1 class="mb-0">Gallery page</h1>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.html" title="Home">Home</a>
                            </li>
                            <li class="breadcrumb-item active">Gallery page</li>
                        </ol>
                    </div>
                    <!-- Page Top Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-130 gray-bg position-relative">
                <div class="container">
                    <div class="gallery-wrap w-100">
                        <div class="row mrg10">
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-1.jpg"
                                        alt="Gallery Image 1"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-1.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-2.jpg"
                                        alt="Gallery Image 2"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-2.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-3.jpg"
                                        alt="Gallery Image 3"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-3.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-4.jpg"
                                        alt="Gallery Image 4"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-4.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-5.jpg"
                                        alt="Gallery Image 5"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-5.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-6.jpg"
                                        alt="Gallery Image 6"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-6.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-7.jpg"
                                        alt="Gallery Image 7"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-7.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-8.jpg"
                                        alt="Gallery Image 8"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-8.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="gallery-box brd-rd20 overflow-hidden position-relative w-100"
                                >
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img1-9.jpg"
                                        alt="Gallery Image 9"
                                    />
                                    <div class="gallery-info position-absolute w-100">
                                        <a
                                            class="rounded-circle thm-bg"
                                            href="assets/images/resources/gallery-img1-9.jpg"
                                            data-fancybox="gallery"
                                            ><i class="fas fa-plus"></i
                                        ></a>
                                        <h3 class="mb-0">
                                            <a href="gallery-detail.html" title="">Listing Title</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Gallery Wrap -->
                </div>
            </div>
        </section>
    </main>
    <!-- Main Wrapper -->
</template>
