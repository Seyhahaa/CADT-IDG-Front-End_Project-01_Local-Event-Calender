<template>
    <main>
        <section>
            <div class="w-100 pt-180 pb-110 black-layer opc45 position-relative">
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/pg-tp-bg.jpg)"
                ></div>
                <div class="container">
                    <div class="pg-tp-wrp text-center w-100">
                        <h1 class="mb-0">Gallery Detail Page</h1>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.html" title="Home">Home</a>
                            </li>
                            <li class="breadcrumb-item active">Gallery Detail Page</li>
                        </ol>
                    </div>
                    <!-- Page Top Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pb-120 gray-bg position-relative">
                <div class="gallery-detail-img w-100">
                    <img
                        class="img-fluid w-100"
                        src="assets/images/resources/gallery-detail-img.jpg"
                        alt="Gallery Detail Image"
                    />
                </div>
                <div class="container">
                    <div class="gallery-detail-wrap bg-white w-100">
                        <div class="gallery-detail-desc w-100">
                            <span class="d-block">6 October</span>
                            <h2 class="mb-0">Gallery Post Format Details</h2>
                            <ul class="gal-meta mb-0 list-unstyled d-inline-flex">
                                <li>
                                    Posted by<a class="thm-clr" href="javascript:void(0);" title=""
                                        >David Richards</a
                                    >
                                </li>
                                <li>
                                    In:<a href="javascript:void(0);" title="">Graphic Design</a>
                                </li>
                                <li><i class="far fa-comment-dots"></i>3</li>
                            </ul>
                            <blockquote>
                                <p class="mb-0">
                                    Mirum est notare quam littera gothica, quam nunc putamus parum
                                    claram, anteposuerit litterarum formas humanitatis per seacula
                                    quarta decima et quinta decima. Eodem modo typi, qui nunc nobis
                                    videntur parum clari, fiant usus.
                                </p>
                            </blockquote>
                            <p class="mb-0">
                                Investigationes demonstraverunt lectores legere me lius quod ii
                                legunt saepius. Claritas est etiam processus dynamicus, qui sequitur
                                mutationem consuetudium lectorum. Mirum est notare quam littera
                                gothica, quam nunc putamus parum claram, anteposuerit litterarum
                                formas humanitatis per seacula quarta decima et quinta decima.
                            </p>
                            <p class="mb-0">
                                Eodem modo typi, qui nunc nobis videntur parum clari, fiant
                                sollemnes in futurum.
                            </p>
                        </div>
                        <div class="gallery-info-inr w-100">
                            <div class="tags w-100">
                                <span>Tags:</span>
                                <a href="javascript:void(0);" title="">Graphic Design</a>,
                                <a href="javascript:void(0);" title="">Photoshop</a>,
                                <a href="javascript:void(0);" title="">Website</a>,
                                <a href="javascript:void(0);" title="">Photography</a>,
                                <a href="javascript:void(0);" title="">Articles</a>
                            </div>
                            <div class="share w-100">
                                <div class="social-links4">
                                    <a
                                        class="facebook rounded-circle"
                                        href="javascript:void(0);"
                                        title="Facebook"
                                        target="_blank"
                                        ><i class="fab fa-facebook-f"></i
                                    ></a>
                                    <a
                                        class="twitter rounded-circle"
                                        href="javascript:void(0);"
                                        title="Twitter"
                                        target="_blank"
                                        ><i class="fab fa-twitter"></i
                                    ></a>
                                    <a
                                        class="youtube rounded-circle"
                                        href="javascript:void(0);"
                                        title="Youtube"
                                        target="_blank"
                                        ><i class="fab fa-youtube"></i
                                    ></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Gallery Detail Wrap -->
                </div>
            </div>
        </section>
    </main>
    <!-- Main Wrapper -->
</template>
