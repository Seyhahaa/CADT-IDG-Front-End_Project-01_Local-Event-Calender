<template>
    <section>
                <div class="w-100 pt-180 pb-110 black-layer opc45 position-relative">
                    <div class="fixed-bg object-cover" style="background-image: url(https://media.istockphoto.com/id/523262976/photo/about-us-concept-with-alphabet-blocks.webp?a=1&b=1&s=612x612&w=0&k=20&c=ivgQiyyuES6Gt7NYF8G84weQ0_iBWNSuERvtcW8Fhu0=);"></div>
                    <div class="container">
                        <div class="pg-tp-wrp text-center w-100">
                            <h1 class="mb-0">អំពីពួកយើង</h1>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html" title="Home">ទំព័រដើម</a></li>
                                <li class="breadcrumb-item active">អំពីពួកយើង</li>
                            </ol>
                        </div><!-- Page Top Wrap -->
                    </div>
                </div>
            </section>
    <section>
        <div class="w-100 pt-110 pb-30 position-relative">
            <div class="container">
                <div class="simple-posts-wrap w-100">
                    <div class="simple-post w-100">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-sm-12 col-lg-6">
                                <div class="simple-img position-relative rounded-circle"><img class="img-fluid w-[30rem] h-[29rem] object-cover rounded-circle" src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDE1fHx8ZW58MHx8fHx8" alt="Simple Post Image 1"></div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-lg-6">
                                <div class="simple-desc w-100">
                                    <h2 class="mb-0 !leading-[5rem]">កម្មវិធីជាច្រើនជិត ៣០០​<br /> នៅក្នុងនេះ</h2>
                                    <p class="mb-0">ព្រឹត្តិការណ៍របស់គាត់ជារឿយៗត្រូវបានរៀបចំជាប្រភេទផ្សេងៗគ្នាដូចជាតន្ត្រីសិល្បៈការអប់រំអាជីវកម្មកីឡាបច្ចេកវិទ្យានិងច្រើនទៀតដែលធ្វើឱ្យវាងាយស្រួលសម្រាប់អ្នកប្រើប្រាស់ក្នុងការស្វែងរកព្រឹត្តិការណ៍ទាក់ទងនឹងផលប្រយោជន៍របស់ពួកគេ។</p>
                                    <ul class="mb-0 list-unstyled w-100">
                                        <li><i class="fas fa-check"></i>ព្រឹត្តិការណ៍នីមួយៗរួមមានព័ត៌មានសំខាន់ៗដូចជាឈ្មោះព្រឹត្តិការណ៍កាលបរិច្ឆេទ ការពិពណ៌នា</li>
                                        <li><i class="fas fa-check"></i>អ្នកប្រើប្រាស់អាចស្វែងរកព្រឹត្តិការណ៍ជាក់លាក់ដោយផ្អែកលើទីតាំងកាលបរិច្ឆេទប្រភេទឬពាក្យគន្លឹះ។</li>
                                        <li><i class="fas fa-check"></i>វេទិកាផ្តល់ចឱ្អ្នកប្រើប្រាស់ចែករំលែកព្រឹត្តិការណ៍ជាមួយមិត្តភក្តិឬធ្វើតាមអ្នករៀបចំព្រឹត្តិការណ៍ដែលពួកគេចូលចិត្ត។</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="simple-post w-100">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-sm-12 col-lg-6 order-md-1">
                                <div class="simple-img position-relative rounded-circle"><img class="img-fluid rounded-circle w-[30rem] h-[29rem] object-cover" src="https://images.unsplash.com/flagged/photo-1568187113326-974ff6d0c6b6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDU3fHx8ZW58MHx8fHx8" alt="Simple Post Image 2"></div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-lg-6">
                                <div class="simple-desc w-100">
                                    <h2 class="mb-0">ឧទាហរណ៍នៃគេហទំព័រចុះបញ្ជីព្រឹត្តិការណ៍ពេញនិយម៖</h2>
                                    <p class="mb-0">វេទិកាដែលត្រូវបានគេប្រើយ៉ាងទូលំទូលាយសម្រាប់ការស្វែងរកនិងរៀបចំព្រឹត្តិការណ៍ផ្តល់ជូនទាំងឧបករណ៍គ្រប់គ្រងព្រឹត្តិការណ៍ឥតគិតថ្លៃនិងបង់ប្រាក់។</p>
                                    <ul class="mb-0 list-unstyled w-100">
                                        <li><i class="fas fa-check"></i>ព្រឹត្តិការណ៍សហគមន៍ដែលជួយអ្នកប្រើប្រាស់ស្វែងរកមនុស្សដែលមានគំនិតដូចគ្នាសម្រាប់សកម្មភាពផ្សេងៗ។</li>
                                        <li><i class="fas fa-check"></i>មគ្គុទេសក៍ព្រឹត្តិការណ៍ពិភពលោកដោយផ្តោតលើសិល្បៈការកម្សាន្តនិងបទពិសោធន៍ក្នុងស្រុកដោយផ្តល់ការចុះបញ្ជីសម្រាប់ទីក្រុងនានានៅជុំវិញពិភពលោក។</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Simple Posts Wrap -->
            </div>
        </div>
    </section>
    <section>
        <div class="w-100 pt-140 pb-90 gray-bg position-relative">
            <div class="container">
                <div class="sec-title text-center w-100">
                    <span class="d-block thm-clr">Discover & connect with great local businesses</span>
                    <h2 class="mb-0">អ្នកជំនាញបច្ចេកទេសរបស់យើង</h2>
                </div><!-- Sec Title -->
                <div class="team-wrap res-row w-100">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="team-box w-100 overflow-hidden position-relative">
                                <img class="img-fluid w-100" src="https://jthemes.net/themes/html/neondir/assets/images/resources/team-img1-1.jpg" alt="Team Image 1">
                                <div class="team-info w-100 position-absolute">
                                    <h3 class="mb-0"><a href="javascript:void(0);" title="">David jame</a></h3>
                                    <span class="d-block">CEO Cunao Business</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="team-box w-100 overflow-hidden position-relative">
                                <img class="img-fluid w-100" src="https://jthemes.net/themes/html/neondir/assets/images/resources/team-img1-2.jpg" alt="Team Image 2">
                                <div class="team-info w-100 position-absolute">
                                    <h3 class="mb-0"><a href="javascript:void(0);" title="">David jame</a></h3>
                                    <span class="d-block">CEO Designer</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-4">
                            <div class="team-box w-100 overflow-hidden position-relative">
                                <img class="img-fluid w-100" src="https://jthemes.net/themes/html/neondir/assets/images/resources/team-img1-3.jpg" alt="Team Image 3">
                                <div class="team-info w-100 position-absolute">
                                    <h3 class="mb-0"><a href="javascript:void(0);" title="">David jame</a></h3>
                                    <span class="d-block">Designer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Team Wrap -->
            </div>
        </div>
    </section>
 

</template>