<template>
    <main>
        <section>
            <div class="w-100 position-relative">
                <div class="feat-wrap3 pt-140 pb-120 black-layer position-relative opc7 w-100">
                    <div
                        class="fixed-bg"
                        style="background-image: url(assets/images/resources/feat-bg3.jpg)"
                    ></div>
                    <div class="container">
                        <div class="feat-inner3 pt-180 text-center w-100">
                            <span class="d-block thm-clr"
                                >Find awesome hotel. tour, car and activities in city</span
                            >
                            <h2 class="mb-0">Find Places You Want to Event</h2>
                            <form class="dir-form3 text-left d-flex flex-wrap align-items-end">
                                <div class="field">
                                    <label>Explore</label>
                                    <input type="text" placeholder="What are you looking for" />
                                    <i class="fas fa-search"></i>
                                </div>
                                <div class="field">
                                    <label>Where</label>
                                    <input type="text" placeholder="Australia" />
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="field-btn">
                                    <button class="thm-btn" type="submit">DISCOVER NOW</button>
                                </div>
                            </form>
                            <div class="dir-cate-wrap text-center w-100">
                                <h4 class="mb-0">Or Browse Featured Categories</h4>
                                <ul class="dir-opt-list d-inline-flex mb-0 list-unstyled">
                                    <li>
                                        <a href="listing-layout.html" title=""
                                            ><span class="rounded-circle"
                                                ><i class="fas fa-hamburger thm-clr"></i
                                            ></span>
                                            <h5 class="mb-0">Concert Event</h5></a
                                        >
                                    </li>
                                    <li>
                                        <a href="listing-layout.html" title=""
                                            ><span class="rounded-circle"
                                                ><i class="fas fa-hotel thm-clr"></i
                                            ></span>
                                            <h5 class="mb-0">Resturants Event</h5></a
                                        >
                                    </li>
                                    <li>
                                        <a href="listing-layout.html" title=""
                                            ><span class="rounded-circle"
                                                ><i class="fas fa-store-alt thm-clr"></i
                                            ></span>
                                            <h5 class="mb-0">Shopping Mall</h5></a
                                        >
                                    </li>
                                    <li>
                                        <a href="listing-layout.html" title=""
                                            ><span class="rounded-circle"
                                                ><i class="fas fa-school thm-clr"></i
                                            ></span>
                                            <h5 class="mb-0">School Event</h5></a
                                        >
                                    </li>
                                    <li>
                                        <a href="listing-layout.html" title=""
                                            ><span class="rounded-circle"
                                                ><i class="fas fa-hamburger thm-clr"></i
                                            ></span>
                                            <h5 class="mb-0">Gym Event</h5></a
                                        >
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Feat Wrap -->
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-130 pb-140 position-relative">
                <div class="container">
                    <div class="post-wrap2 w-100">
                        <div class="post-box2 d-flex flex-wrap align-items-center w-100">
                            <div class="post-img2">
                                <img
                                    class="img-fluid"
                                    src="assets/images/resources/post-img2-1.jpg"
                                    alt="Post Image 1"
                                />
                            </div>
                            <div class="post-info2">
                                <h3 class="mb-0">Events by Location</h3>
                                <p class="mb-0">
                                    Luxury hotel in the heart of BloomsburyLuxury hotel in the heart
                                    of Bloomsbury..
                                </p>
                                <a class="thm-btn" href="event-detail.html" title=""
                                    >Discover Now</a
                                >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pb-140 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">Explore Event</span>
                        <h3 class="mb-0">Browse the highlights</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="highlights-wrap res-row w-100">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="highlight-box v2 overflow-hidden position-relative w-100"
                                >
                                    <div
                                        class="highlight-img overflow-hidden position-relative w-100"
                                    >
                                        <div class="btns-wrap position-absolute">
                                            <a
                                                class="rounded-circle"
                                                href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                data-fancybox
                                                title=""
                                                ><i class="fas fa-video"></i
                                            ></a>
                                            <a
                                                class="rounded-circle"
                                                href="assets/images/resources/highlight-img5-1.jpg"
                                                data-fancybox
                                                title=""
                                                ><i class="far fa-image"></i
                                            ></a>
                                        </div>
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/highlight-img5-1.jpg"
                                            alt="Highlight Image 1"
                                        />
                                    </div>
                                    <div class="highlight-info position-relative">
                                        <span class="thm-clr">09 Sep</span>
                                        <h3 class="mb-0">
                                            <a href="event-detail2.html" title=""
                                                >Dublin Tech Summit</a
                                            >
                                        </h3>
                                        <span class="d-block"
                                            ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                            Spain</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="highlight-box v2 overflow-hidden position-relative w-100"
                                >
                                    <div
                                        class="highlight-img overflow-hidden position-relative w-100"
                                    >
                                        <div class="btns-wrap position-absolute">
                                            <a
                                                class="rounded-circle"
                                                href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                data-fancybox
                                                title=""
                                                ><i class="fas fa-video"></i
                                            ></a>
                                            <a
                                                class="rounded-circle"
                                                href="assets/images/resources/highlight-img5-2.jpg"
                                                data-fancybox
                                                title=""
                                                ><i class="far fa-image"></i
                                            ></a>
                                        </div>
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/highlight-img5-2.jpg"
                                            alt="Highlight Image 2"
                                        />
                                    </div>
                                    <div class="highlight-info position-relative">
                                        <span class="thm-clr">09 Sep</span>
                                        <h3 class="mb-0">
                                            <a href="event-detail2.html" title=""
                                                >Dublin Tech Summit</a
                                            >
                                        </h3>
                                        <span class="d-block"
                                            ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                            Spain</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div
                                    class="highlight-box v2 overflow-hidden position-relative w-100"
                                >
                                    <div
                                        class="highlight-img overflow-hidden position-relative w-100"
                                    >
                                        <div class="btns-wrap position-absolute">
                                            <a
                                                class="rounded-circle"
                                                href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                data-fancybox
                                                title=""
                                                ><i class="fas fa-video"></i
                                            ></a>
                                            <a
                                                class="rounded-circle"
                                                href="assets/images/resources/highlight-img5-3.jpg"
                                                data-fancybox
                                                title=""
                                                ><i class="far fa-image"></i
                                            ></a>
                                        </div>
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/highlight-img5-3.jpg"
                                            alt="Highlight Image 3"
                                        />
                                    </div>
                                    <div class="highlight-info position-relative">
                                        <span class="thm-clr">09 Sep</span>
                                        <h3 class="mb-0">
                                            <a href="event-detail2.html" title=""
                                                >Dublin Tech Summit</a
                                            >
                                        </h3>
                                        <span class="d-block"
                                            ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                            Spain</span
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Highlights Wrap -->
                    <div class="view-all mt-30 text-center w-100">
                        <a class="thm-btn" href="listing-layout.html" title="">Discover Now</a>
                    </div>
                    <!-- View All -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-80 gray-bg4 pb-140 position-relative">
                <div class="container">
                    <div class="highlight-mockp-wrap w-100">
                        <div class="row align-items-center">
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <div class="highlight-mockup">
                                    <img
                                        class="img-fluid"
                                        src="assets/images/resources/highligh-mockup.png"
                                        alt="Highlights Mockup"
                                    />
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <div class="sec-title w-100">
                                    <span class="d-block thm-clr">Popular Event</span>
                                    <h3 class="mb-0">Browse the highlights</h3>
                                </div>
                                <!-- Sec Title -->
                                <div class="listing-posts-wrap2 w-100">
                                    <div class="listing-post-box3 v2 d-flex flex-wrap w-100">
                                        <div class="listing-post-img3">
                                            <a href="event-detail.html" title=""
                                                ><img
                                                    class="img-fluid w-100"
                                                    src="assets/images/resources/list-post-img4-1.jpg"
                                                    alt="List Post Image 1"
                                            /></a>
                                        </div>
                                        <div class="list-post-info3">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>60</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail.html" title=""
                                                    >MWC Barcelona 2021</a
                                                >
                                            </h3>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="listing-post-box3 v2 d-flex flex-wrap w-100">
                                        <div class="listing-post-img3">
                                            <a href="event-detail.html" title=""
                                                ><img
                                                    class="img-fluid w-100"
                                                    src="assets/images/resources/list-post-img4-2.jpg"
                                                    alt="List Post Image 2"
                                            /></a>
                                        </div>
                                        <div class="list-post-info3">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>40</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail.html" title=""
                                                    >MWC Barcelona 2021</a
                                                >
                                            </h3>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="listing-post-box3 v2 d-flex flex-wrap w-100">
                                        <div class="listing-post-img3">
                                            <a href="event-detail.html" title=""
                                                ><img
                                                    class="img-fluid w-100"
                                                    src="assets/images/resources/list-post-img4-3.jpg"
                                                    alt="List Post Image 3"
                                            /></a>
                                        </div>
                                        <div class="list-post-info3">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail.html" title=""
                                                    >MWC Barcelona 2021</a
                                                >
                                            </h3>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="view-all mt-70 w-100">
                                    <a class="thm-btn" href="listing-layout.html" title=""
                                        >View All</a
                                    >
                                </div>
                                <!-- View All -->
                            </div>
                        </div>
                    </div>
                    <!-- Highlights with Mockup Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-120 dark-layer4 opc95 pb-50 position-relative">
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/parallax1.jpg)"
                ></div>
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr"
                            >We arrange many other events & party for enjoy</span
                        >
                        <h2 class="mb-0">Upcoming Events</h2>
                    </div>
                    <!-- Sec Title -->
                    <div class="event-videos-wrap event-video-caro">
                        <div class="event-video-box text-center">
                            <div class="event-video-img overflow-hidden position-relative w-100">
                                <a
                                    class="rounded-circle position-absolute"
                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                    data-fancybox
                                    title=""
                                    ><i class="fas fa-play"></i
                                ></a>
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/event-video-img1-1.jpg"
                                    alt="Event Video Image 1"
                                />
                            </div>
                            <div class="event-video-info">
                                <h3 class="mb-0">
                                    <a href="javascript:void(0);" title="">After the Party</a>
                                </h3>
                                <span class="d-inline-block"
                                    ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                    Spain</span
                                >
                            </div>
                        </div>
                        <div class="event-video-box text-center">
                            <div class="event-video-img overflow-hidden position-relative w-100">
                                <a
                                    class="rounded-circle position-absolute"
                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                    data-fancybox
                                    title=""
                                    ><i class="fas fa-play"></i
                                ></a>
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/event-video-img1-2.jpg"
                                    alt="Event Video Image 2"
                                />
                            </div>
                            <div class="event-video-info">
                                <h3 class="mb-0">
                                    <a href="javascript:void(0);" title="">After the Party</a>
                                </h3>
                                <span class="d-inline-block"
                                    ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                    Spain</span
                                >
                            </div>
                        </div>
                        <div class="event-video-box text-center">
                            <div class="event-video-img overflow-hidden position-relative w-100">
                                <a
                                    class="rounded-circle position-absolute"
                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                    data-fancybox
                                    title=""
                                    ><i class="fas fa-play"></i
                                ></a>
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/event-video-img1-3.jpg"
                                    alt="Event Video Image 3"
                                />
                            </div>
                            <div class="event-video-info">
                                <h3 class="mb-0">
                                    <a href="javascript:void(0);" title="">After the Party</a>
                                </h3>
                                <span class="d-inline-block"
                                    ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                    Spain</span
                                >
                            </div>
                        </div>
                        <div class="event-video-box text-center">
                            <div class="event-video-img overflow-hidden position-relative w-100">
                                <a
                                    class="rounded-circle position-absolute"
                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                    data-fancybox
                                    title=""
                                    ><i class="fas fa-play"></i
                                ></a>
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/event-video-img1-4.jpg"
                                    alt="Event Video Image 4"
                                />
                            </div>
                            <div class="event-video-info">
                                <h3 class="mb-0">
                                    <a href="javascript:void(0);" title="">After the Party</a>
                                </h3>
                                <span class="d-inline-block"
                                    ><i class="thm-clr fas fa-map-marker-alt"></i>Barcelona,
                                    Spain</span
                                >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-100 position-relative">
                <div class="container">
                    <div class="post-wrap2 w-100">
                        <div class="post-box2 v2 d-flex flex-wrap align-items-center w-100">
                            <div class="post-img2">
                                <img
                                    class="img-fluid"
                                    src="assets/images/resources/post-img2-2.png"
                                    alt="Post Image 2"
                                />
                            </div>
                            <div class="post-info2">
                                <h3 class="mb-0">
                                    <a href="event-detail.html" title="">Break the Mountains</a>
                                </h3>
                                <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                    <li>
                                        <i class="fas fa-map-marker-alt rounded-circle"></i>AKM
                                        Auditorium, LA, USA
                                    </li>
                                    <li><i class="thm-clr far fa-clock"></i>10 Am - 01 Pm</li>
                                </ul>
                                <p class="mb-0">
                                    In iriure scripserit vix, vis id modo soluta. Meis utinam quo
                                    at, esse aeterno adversarium ei has, ad
                                </p>
                                <a class="thm-btn" href="event-detail.html" title=""
                                    >Discover Now</a
                                >
                            </div>
                        </div>
                        <div class="post-box2 v2 rev d-flex flex-wrap align-items-center w-100">
                            <div class="post-img2">
                                <img
                                    class="img-fluid"
                                    src="assets/images/resources/post-img2-3.png"
                                    alt="Post Image 3"
                                />
                            </div>
                            <div class="post-info2">
                                <h3 class="mb-0">
                                    <a href="event-detail.html" title="">Rock Party With DJ</a>
                                </h3>
                                <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                    <li>
                                        <i class="fas fa-map-marker-alt rounded-circle"></i>AKM
                                        Auditorium, LA, USA
                                    </li>
                                    <li><i class="thm-clr far fa-clock"></i>10 Am - 01 Pm</li>
                                </ul>
                                <p class="mb-0">
                                    In iriure scripserit vix, vis id modo soluta. Meis utinam quo
                                    at, esse aeterno adversarium ei has, ad
                                </p>
                                <a class="thm-btn" href="event-detail.html" title=""
                                    >Discover Now</a
                                >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 position-relative">
                <ul class="gallery-wrap d-flex flex-wrap mb-0 w-100 list-unstyled">
                    <li>
                        <div class="gallery-box2 overflow-hidden position-relative w-100">
                            <a
                                href="assets/images/resources/gallery-img4-1.jpg"
                                data-fancybox="gallery"
                                title=""
                                ><img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/gallery-img4-1.jpg"
                                    alt="Gallery Image 1"
                            /></a>
                        </div>
                    </li>
                    <li>
                        <div class="gallery-box2 overflow-hidden position-relative w-100">
                            <a
                                href="assets/images/resources/gallery-img4-2.jpg"
                                data-fancybox="gallery"
                                title=""
                                ><img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/gallery-img4-2.jpg"
                                    alt="Gallery Image 2"
                            /></a>
                        </div>
                    </li>
                    <li>
                        <div class="gallery-box2 overflow-hidden position-relative w-100">
                            <a
                                href="assets/images/resources/gallery-img4-3.jpg"
                                data-fancybox="gallery"
                                title=""
                                ><img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/gallery-img4-3.jpg"
                                    alt="Gallery Image 3"
                            /></a>
                        </div>
                    </li>
                    <li>
                        <div class="gallery-box2 overflow-hidden position-relative w-100">
                            <a
                                href="assets/images/resources/gallery-img4-4.jpg"
                                data-fancybox="gallery"
                                title=""
                                ><img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/gallery-img4-4.jpg"
                                    alt="Gallery Image 4"
                            /></a>
                        </div>
                    </li>
                    <li>
                        <div class="gallery-box2 overflow-hidden position-relative w-100">
                            <a
                                href="assets/images/resources/gallery-img4-5.jpg"
                                data-fancybox="gallery"
                                title=""
                                ><img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/gallery-img4-5.jpg"
                                    alt="Gallery Image 5"
                            /></a>
                        </div>
                    </li>
                </ul>
            </div>
            <!-- Gallery Wrap -->
        </section>
    </main>
    <!-- Main Wrapper -->
</template>
