<template>
    <main>
        <section>
            <div class="w-100 position-relative">
                <img
                    class="rgt-btm-shp sec-shp position-absolute img-fluid w-100"
                    src="assets/images/shp1.png"
                    alt="Shape 1"
                />
                <div class="feat-wrap2 pt-140 pb-140 black-layer position-relative opc2 w-100">
                    <div
                        class="fixed-bg"
                        style="background-image: url(assets/images/resources/feat-bg2.jpg)"
                    ></div>
                    <div class="container">
                        <div class="feat-inner2 pt-80 pb-10 text-center w-100">
                            <span class="d-block"
                                >Explore all the popular places, visit cities</span
                            >
                            <h2 class="mb-0">
                                Find Places You <br />
                                Want To Go
                            </h2>
                            <form class="dir-form2 text-left d-flex flex-wrap align-items-end">
                                <div class="field">
                                    <label
                                        ><i class="fas fa-map-pin"></i>What you'd like to
                                        find?</label
                                    >
                                    <input type="text" placeholder="Keyword to search" />
                                </div>
                                <div class="field">
                                    <label
                                        ><i class="fas fa-map-marker-alt"></i>Where to look
                                        for?</label
                                    >
                                    <input type="text" placeholder="Search for location" />
                                </div>
                                <div class="field">
                                    <label><i class="far fa-flag"></i>In which category?</label>
                                    <input type="text" placeholder="All Categories" />
                                </div>
                                <div class="field-btn">
                                    <button class="thm-btn" type="submit">
                                        <i class="fas fa-search"></i>DISCOVER NOW
                                    </button>
                                </div>
                            </form>
                            <p class="mb-0">
                                These are the event directory sites that allow the users to post
                                events <br />
                                and view them
                                <a href="javascript:void(0);" title="">The directory theme</a>
                                with the events
                            </p>
                        </div>
                        <!-- Feat Wrap -->
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-140 position-relative">
                <img
                    class="tp-lft-shp position-absolute"
                    src="assets/images/tp-lft-shp.png"
                    alt="Top Left Shape"
                />
                <div class="container">
                    <div class="desti-wrap w-100">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-sm-12 col-lg-4">
                                <div class="sec-title v2 w-100">
                                    <span class="d-block thm-clr">Explore Event</span>
                                    <h3 class="mb-0">More Featured Destination</h3>
                                    <p class="mb-0">
                                        Luxury hotel in the Bloomsbury Luxury hotel in the heart of
                                        Bloomsbury..
                                    </p>
                                    <a class="thm-btn" href="about.html" title="place-listing.html"
                                        >Discover Now</a
                                    >
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-lg-8">
                                <div class="desti-posts-wrap">
                                    <div class="row desti-caro">
                                        <div class="col-md-4 col-sm-6 col-lg-3">
                                            <div class="desti-box w-100">
                                                <div
                                                    class="desti-img w-100 overflow-hidden position-relative"
                                                >
                                                    <a href="place-listing.html" title=""
                                                        ><img
                                                            class="img-fluid w-100"
                                                            src="assets/images/resources/desti-img1-1.jpg"
                                                            alt="Destination Image 1"
                                                    /></a>
                                                </div>
                                                <div class="desti-info w-100">
                                                    <h3 class="mb-0">
                                                        <a href="place-listing.html" title=""
                                                            >San Franciso</a
                                                        >
                                                    </h3>
                                                    <span class="d-block"
                                                        >( 20, Listing Events )</span
                                                    >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
                                            <div class="desti-box w-100">
                                                <div
                                                    class="desti-img w-100 overflow-hidden position-relative"
                                                >
                                                    <a href="place-listing.html" title=""
                                                        ><img
                                                            class="img-fluid w-100"
                                                            src="assets/images/resources/desti-img1-2.jpg"
                                                            alt="Destination Image 2"
                                                    /></a>
                                                </div>
                                                <div class="desti-info w-100">
                                                    <h3 class="mb-0">
                                                        <a href="place-listing.html" title=""
                                                            >London</a
                                                        >
                                                    </h3>
                                                    <span class="d-block"
                                                        >( 30, Listing Events )</span
                                                    >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
                                            <div class="desti-box w-100">
                                                <div
                                                    class="desti-img w-100 overflow-hidden position-relative"
                                                >
                                                    <a href="place-listing.html" title=""
                                                        ><img
                                                            class="img-fluid w-100"
                                                            src="assets/images/resources/desti-img1-3.jpg"
                                                            alt="Destination Image 3"
                                                    /></a>
                                                </div>
                                                <div class="desti-info w-100">
                                                    <h3 class="mb-0">
                                                        <a href="place-listing.html" title=""
                                                            >Tokyo</a
                                                        >
                                                    </h3>
                                                    <span class="d-block"
                                                        >( 15, Listing Events )</span
                                                    >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-lg-3">
                                            <div class="desti-box w-100">
                                                <div
                                                    class="desti-img w-100 overflow-hidden position-relative"
                                                >
                                                    <a href="place-listing.html" title=""
                                                        ><img
                                                            class="img-fluid w-100"
                                                            src="assets/images/resources/desti-img1-4.jpg"
                                                            alt="Destination Image 4"
                                                    /></a>
                                                </div>
                                                <div class="desti-info w-100">
                                                    <h3 class="mb-0">
                                                        <a href="place-listing.html" title=""
                                                            >Australia</a
                                                        >
                                                    </h3>
                                                    <span class="d-block"
                                                        >( 45, Listing Events )</span
                                                    >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Destination Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 gray-layer3 opc65 position-relative">
                <img
                    class="tp-rgt-shp position-absolute"
                    src="assets/images/tp-rgt-shp.png"
                    alt="Top Right Shape"
                />
                <img
                    class="rgt-tp-shp sec-shp position-absolute img-fluid w-100"
                    src="assets/images/shp4.png"
                    alt="Shape 4"
                />
                <div
                    class="fixed-bg patern-bg"
                    style="background-image: url(assets/images/pattern-bg2.png)"
                ></div>
                <div class="container">
                    <div class="explor-wrap w-100">
                        <div class="row align-items-center">
                            <div class="col-md-12 col-sm-12 col-lg-7">
                                <div class="explor-img">
                                    <img
                                        class="img-fluid slide-animation w-100"
                                        src="assets/images/resources/explor-mockup.png"
                                        alt="Explore Mockup"
                                    />
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-5">
                                <div class="explor-cont">
                                    <div class="sec-title v2 w-100">
                                        <h3 class="mb-0">Explore on-going and Upcoming Events</h3>
                                        <p class="mb-0">
                                            Luxury hotel in the Bloomsbury Luxury <br />
                                            hotel in the heart of Bloomsbury..
                                        </p>
                                    </div>
                                    <div class="serv-wrap w-100">
                                        <div class="serv-box w-100">
                                            <span class="rounded-circle"
                                                ><img
                                                    class="img-fluid"
                                                    src="assets/images/resources/serv-icon1-1.png"
                                                    alt="Service Icon 1"
                                            /></span>
                                            <div class="serv-info">
                                                <h3 class="mb-0">Find the perfect venue</h3>
                                                <p class="mb-0">
                                                    Luxury hotel in the heart of Bloomsbury Luxury
                                                </p>
                                            </div>
                                        </div>
                                        <div class="serv-box w-100">
                                            <span class="rounded-circle"
                                                ><img
                                                    class="img-fluid"
                                                    src="assets/images/resources/serv-icon1-2.png"
                                                    alt="Service Icon 2"
                                            /></span>
                                            <div class="serv-info">
                                                <h3 class="mb-0">Enjoy your perfect event</h3>
                                                <p class="mb-0">
                                                    Luxury hotel in the heart of Bloomsbury Luxury
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <a class="thm-btn" href="about.html" title="">Discover Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Explore Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-110 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">Explore Event</span>
                        <h3 class="mb-0">Popular Categories Events?</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="city-wrap2 w-100">
                        <div class="row">
                            <div class="col-md-6 col-sm-12 col-lg-5">
                                <div class="city-box2 overflow-hidden position-relative w-100">
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/city-img2-1.jpg"
                                        alt="City Image 1"
                                    />
                                    <div
                                        class="city-info2 d-flex flex-wrap justify-content-between align-items-center position-absolute w-100"
                                    >
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title="">Having Fun</a>
                                        </h3>
                                        <span class="d-inline-block">( 20, Listing )</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-lg-5 order-lg-1">
                                <div class="city-box2 overflow-hidden position-relative w-100">
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/city-img2-2.jpg"
                                        alt="City Image 2"
                                    />
                                    <div
                                        class="city-info2 d-flex flex-wrap justify-content-between align-items-center position-absolute w-100"
                                    >
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title="">Night Club</a>
                                        </h3>
                                        <span class="d-inline-block">( 25, Listing )</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-7">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img2-3.jpg"
                                                alt="City Image 3"
                                            />
                                            <div
                                                class="city-info2 d-flex flex-wrap justify-content-between align-items-center position-absolute w-100"
                                            >
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >After the Parly</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block">( 30, Listing )</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img2-4.jpg"
                                                alt="City Image 4"
                                            />
                                            <div
                                                class="city-info2 d-flex flex-wrap justify-content-between align-items-center position-absolute w-100"
                                            >
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >Famous Singers</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block">( 35, Listing )</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-7">
                                <div class="city-box2 overflow-hidden position-relative w-100">
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/city-img2-5.jpg"
                                        alt="City Image 5"
                                    />
                                    <div
                                        class="city-info2 d-flex flex-wrap justify-content-between align-items-center position-absolute w-100"
                                    >
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title=""
                                                >Festival Events</a
                                            >
                                        </h3>
                                        <span class="d-inline-block">( 45, Listing )</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- City Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 dark-layer3 opc9 pb-110 position-relative">
                <img
                    class="rgt-tp-shp sec-shp position-absolute img-fluid w-100"
                    src="assets/images/shp2.png"
                    alt="Shape 2"
                />
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/parallax3.jpg)"
                ></div>
                <div class="container">
                    <div
                        class="title-tabs d-flex flex-wrap align-items-center justify-content-between w-100"
                    >
                        <div class="sec-title">
                            <span class="d-block thm-clr">Popular Event</span>
                            <h2 class="mb-0">Browse the highlights</h2>
                        </div>
                        <!-- Sec Title -->
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tab1-1"
                                    >Eat & Drink</a
                                >
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tab1-2">Shopping</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tab1-3">Hotels</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tab1-4">Nightlife</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="highlights-wrap px-60 w-100">
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="tab1-1">
                            <div class="row highlight-caro">
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img1-1.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img1-1.jpg"
                                                alt="Highlight Image 1"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img1-2.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img1-2.jpg"
                                                alt="Highlight Image 2"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img1-3.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img1-3.jpg"
                                                alt="Highlight Image 3"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img1-4.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img1-4.jpg"
                                                alt="Highlight Image 4"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img1-5.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img1-5.jpg"
                                                alt="Highlight Image 5"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab1-2">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img2-1.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img2-1.jpg"
                                                alt="Highlight Image 1"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img2-2.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img2-2.jpg"
                                                alt="Highlight Image 2"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img2-3.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img2-3.jpg"
                                                alt="Highlight Image 3"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img2-4.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img2-4.jpg"
                                                alt="Highlight Image 4"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab1-3">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img3-1.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img3-1.jpg"
                                                alt="Highlight Image 1"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img3-2.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img3-2.jpg"
                                                alt="Highlight Image 2"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img3-3.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img3-3.jpg"
                                                alt="Highlight Image 3"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img3-4.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img3-4.jpg"
                                                alt="Highlight Image 4"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab1-4">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img4-1.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img4-1.jpg"
                                                alt="Highlight Image 1"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img4-2.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img4-2.jpg"
                                                alt="Highlight Image 2"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img4-3.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img4-3.jpg"
                                                alt="Highlight Image 3"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-3">
                                    <div
                                        class="highlight-box overflow-hidden position-relative w-100"
                                    >
                                        <div
                                            class="highlight-img overflow-hidden position-relative w-100"
                                        >
                                            <span class="rounded-pill position-absolute"
                                                >Featured</span
                                            >
                                            <div class="btns-wrap position-absolute">
                                                <a
                                                    class="rounded-circle"
                                                    href="https://www.youtube.com/embed/7EdpBH81XIY"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="fas fa-video"></i
                                                ></a>
                                                <a
                                                    class="rounded-circle"
                                                    href="assets/images/resources/highlight-img4-4.jpg"
                                                    data-fancybox
                                                    title=""
                                                    ><i class="far fa-image"></i
                                                ></a>
                                            </div>
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/highlight-img4-4.jpg"
                                                alt="Highlight Image 4"
                                            />
                                        </div>
                                        <div class="highlight-info position-absolute">
                                            <span class="thm-clr">09 Sep</span>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Dublin Tech Summit</a
                                                >
                                            </h3>
                                            <span class="d-block"
                                                ><i class="thm-clr fas fa-map-marker-alt"></i
                                                >Barcelona, Spain</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Highlights Wrap -->
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-100 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr"
                            >We arrange many other events & party for enjoy</span
                        >
                        <h3 class="mb-0">Upcoming Events</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="upcoming-wrap w-100">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <div class="upcoming-event-box w-100">
                                    <div
                                        class="upcoming-event-img overflow-hidden position-relative w-100"
                                    >
                                        <a href="event-detail2.html" title=""
                                            ><img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/upcoming-event-img1-1.jpg"
                                                alt="Upcoming Event Image 1"
                                        /></a>
                                    </div>
                                    <div class="upcoming-event-info w-100">
                                        <span
                                            class="upcoming-post-date position-absolute thm-bg rounded-pill"
                                            >May 28, 2018</span
                                        >
                                        <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                            <li>
                                                <i class="thm-clr far fa-clock"></i>10 Am - 01 Pm
                                            </li>
                                            <li><i class="thm-clr fas fa-users"></i>50</li>
                                        </ul>
                                        <h3 class="mb-0">
                                            <a href="event-detail2.html" title=""
                                                >MWC Barcelona 2021</a
                                            >
                                        </h3>
                                        <p class="mb-0">
                                            We provide event and directory listings of restaurants,
                                            museums, art centers, theaters, and landmarks.
                                        </p>
                                        <span class="d-block loc-pos"
                                            ><i
                                                class="thm-clr fas fa-map-marker-alt rounded-circle"
                                            ></i
                                            >95 South Park Avenue</span
                                        >
                                    </div>
                                    <div class="upcoming-event-counter w-100">
                                        <ul
                                            class="countdown d-inline-flex flex-wrap mb-0 list-unstyled w-100"
                                        >
                                            <li>
                                                <span class="days">103</span>
                                                <p class="days_ref theme-clr">days</p>
                                            </li>
                                            <li>
                                                <span class="hours">00</span>
                                                <p class="hours_ref theme-clr">hours</p>
                                            </li>
                                            <li>
                                                <span class="minutes">23</span>
                                                <p class="minutes_ref theme-clr">min</p>
                                            </li>
                                            <li>
                                                <span class="seconds">48</span>
                                                <p class="seconds_ref theme-clr">sec</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <div class="upcoming-event-box w-100">
                                    <div
                                        class="upcoming-event-img overflow-hidden position-relative w-100"
                                    >
                                        <a href="event-detail2.html" title=""
                                            ><img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/upcoming-event-img1-2.jpg"
                                                alt="Upcoming Event Image 2"
                                        /></a>
                                    </div>
                                    <div class="upcoming-event-info w-100">
                                        <span
                                            class="upcoming-post-date position-absolute thm-bg rounded-pill"
                                            >May 28, 2018</span
                                        >
                                        <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                            <li>
                                                <i class="thm-clr far fa-clock"></i>10 Am - 01 Pm
                                            </li>
                                            <li><i class="thm-clr fas fa-users"></i>50</li>
                                        </ul>
                                        <h3 class="mb-0">
                                            <a href="event-detail2.html" title=""
                                                >MWC Barcelona 2021</a
                                            >
                                        </h3>
                                        <p class="mb-0">
                                            We provide event and directory listings of restaurants,
                                            museums, art centers, theaters, and landmarks.
                                        </p>
                                        <span class="d-block loc-pos"
                                            ><i
                                                class="thm-clr fas fa-map-marker-alt rounded-circle"
                                            ></i
                                            >95 South Park Avenue</span
                                        >
                                    </div>
                                    <div class="upcoming-event-counter w-100">
                                        <ul
                                            class="countdown d-inline-flex flex-wrap mb-0 list-unstyled w-100"
                                        >
                                            <li>
                                                <span class="days">103</span>
                                                <p class="days_ref theme-clr">days</p>
                                            </li>
                                            <li>
                                                <span class="hours">00</span>
                                                <p class="hours_ref theme-clr">hours</p>
                                            </li>
                                            <li>
                                                <span class="minutes">23</span>
                                                <p class="minutes_ref theme-clr">min</p>
                                            </li>
                                            <li>
                                                <span class="seconds">48</span>
                                                <p class="seconds_ref theme-clr">sec</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Upcoming Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 position-relative">
                <div class="sec-title text-center w-100">
                    <span class="d-block thm-clr">Highlights Event</span>
                    <h3 class="mb-0">Image Gallery Event</h3>
                </div>
                <!-- Sec Title -->
                <div class="gallery-wrap w-100">
                    <div class="row mrg">
                        <div class="col-md-6 col-sm-6 col-lg-3">
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-1.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-1.jpg"
                                        alt="Gallery Image 1"
                                /></a>
                            </div>
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-2.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-2.jpg"
                                        alt="Gallery Image 2"
                                /></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3">
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-3.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-3.jpg"
                                        alt="Gallery Image 3"
                                /></a>
                            </div>
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-4.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-4.jpg"
                                        alt="Gallery Image 4"
                                /></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3">
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-5.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-5.jpg"
                                        alt="Gallery Image 5"
                                /></a>
                            </div>
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-6.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-6.jpg"
                                        alt="Gallery Image 6"
                                /></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3">
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-7.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-7.jpg"
                                        alt="Gallery Image 7"
                                /></a>
                            </div>
                            <div class="gallery-box2 overflow-hidden position-relative w-100">
                                <a
                                    href="assets/images/resources/gallery-img2-8.jpg"
                                    data-fancybox="gallery"
                                    title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/gallery-img2-8.jpg"
                                        alt="Gallery Image 8"
                                /></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Gallery Wrap -->
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 gray-layer3 pb-50 opc65 position-relative">
                <div
                    class="fixed-bg patern-bg"
                    style="background-image: url(assets/images/pattern-bg2.png)"
                ></div>
                <div class="container">
                    <div class="testi-wrap2 w-100">
                        <div class="row justify-content-center">
                            <div class="col-md-12 col-sm-12 col-lg-10">
                                <div class="texti-inner w-100">
                                    <div class="testi-nav-caro">
                                        <div class="testi-nav-img">
                                            <img
                                                class="img-fluid rounded-circle"
                                                src="assets/images/resources/testi-nav-img1-1.jpg"
                                                alt="Testimonials Image 1"
                                            />
                                        </div>
                                        <div class="testi-nav-img">
                                            <img
                                                class="img-fluid rounded-circle"
                                                src="assets/images/resources/testi-nav-img1-2.jpg"
                                                alt="Testimonials Image 2"
                                            />
                                        </div>
                                        <div class="testi-nav-img">
                                            <img
                                                class="img-fluid rounded-circle"
                                                src="assets/images/resources/testi-nav-img1-3.jpg"
                                                alt="Testimonials Image 3"
                                            />
                                        </div>
                                        <div class="testi-nav-img">
                                            <img
                                                class="img-fluid rounded-circle"
                                                src="assets/images/resources/testi-nav-img1-4.jpg"
                                                alt="Testimonials Image 4"
                                            />
                                        </div>
                                    </div>
                                    <div class="testi-data-caro">
                                        <div class="testi-content-item">
                                            <p class="mb-0">
                                                “ Vestibulum varius, velit sit amet tempor
                                                efficitur, ligula mi lacinia libero, et vehicula dui
                                                nisi eget purus.Curabitur scelerisque, nibh non
                                                venenatis euismod ”
                                            </p>
                                            <h4 class="mb-0">Marry Julyet</h4>
                                            <span class="thm-clr d-block">Varsity Intercom</span>
                                        </div>
                                        <div class="testi-content-item">
                                            <p class="mb-0">
                                                “ Vestibulum varius, velit sit amet tempor
                                                efficitur, ligula mi lacinia libero, et vehicula dui
                                                nisi eget purus.Curabitur scelerisque, nibh non
                                                venenatis euismod ”
                                            </p>
                                            <h4 class="mb-0">Marry Julyet</h4>
                                            <span class="thm-clr d-block">Varsity Intercom</span>
                                        </div>
                                        <div class="testi-content-item">
                                            <p class="mb-0">
                                                “ Vestibulum varius, velit sit amet tempor
                                                efficitur, ligula mi lacinia libero, et vehicula dui
                                                nisi eget purus.Curabitur scelerisque, nibh non
                                                venenatis euismod ”
                                            </p>
                                            <h4 class="mb-0">Marry Julyet</h4>
                                            <span class="thm-clr d-block">Varsity Intercom</span>
                                        </div>
                                        <div class="testi-content-item">
                                            <p class="mb-0">
                                                “ Vestibulum varius, velit sit amet tempor
                                                efficitur, ligula mi lacinia libero, et vehicula dui
                                                nisi eget purus.Curabitur scelerisque, nibh non
                                                venenatis euismod ”
                                            </p>
                                            <h4 class="mb-0">Marry Julyet</h4>
                                            <span class="thm-clr d-block">Varsity Intercom</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonials Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-100 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">Highlights Event</span>
                        <h3 class="mb-0">Recent News</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="blog-wrap res-row w-100">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="blog-post-box w-100">
                                    <div class="blog-post-img overflow-hidden w-100">
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/blog-img1-4.jpg"
                                                alt="Blog Image 4"
                                        /></a>
                                    </div>
                                    <div class="blog-post-info bg-white w-100">
                                        <span class="post-date d-inline-block">6 October</span>
                                        <h3 class="mb-0">
                                            <a href="javascript:void(0);" title=""
                                                >Standard Post Format</a
                                            >
                                        </h3>
                                        <p class="mb-0">
                                            Qui nunc nobis videntur parum clari, sollemnes in
                                            futurum putamus parum claram legere.
                                        </p>
                                        <span class="post-auth d-inline-block"
                                            >Posted by
                                            <a href="javascript:void(0);" title=""
                                                >Jessica Doen</a
                                            ></span
                                        >
                                        <span class="post-coment thm-bg position-absolute"
                                            ><i class="far fa-comment-dots"></i>03</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="blog-post-box w-100">
                                    <div class="blog-post-img overflow-hidden w-100">
                                        <iframe
                                            src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/867623335&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"
                                        ></iframe>
                                    </div>
                                    <div class="blog-post-info bg-white w-100">
                                        <span class="post-date d-inline-block">19 August</span>
                                        <h3 class="mb-0">
                                            <a href="javascript:void(0);" title=""
                                                >Audio Post Format</a
                                            >
                                        </h3>
                                        <p class="mb-0">
                                            Qui nunc nobis videntur parum clari, sollemnes in
                                            futurum putamus parum claram legere.
                                        </p>
                                        <span class="post-auth d-inline-block"
                                            >Posted by
                                            <a href="javascript:void(0);" title=""
                                                >Robin Miles</a
                                            ></span
                                        >
                                        <span class="post-coment thm-bg position-absolute"
                                            ><i class="far fa-comment-dots"></i>03</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="blog-post-box w-100">
                                    <div class="blog-post-img overflow-hidden w-100">
                                        <a href="javascript:void(0);" title=""
                                            ><img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/blog-img1-5.jpg"
                                                alt="Blog Image 5"
                                        /></a>
                                    </div>
                                    <div class="blog-post-info bg-white w-100">
                                        <span class="post-date d-inline-block">11 June</span>
                                        <h3 class="mb-0">
                                            <a href="javascript:void(0);" title=""
                                                >Standard Post Format</a
                                            >
                                        </h3>
                                        <p class="mb-0">
                                            Qui nunc nobis videntur parum clari, sollemnes in
                                            futurum putamus parum claram legere.
                                        </p>
                                        <span class="post-auth d-inline-block"
                                            >Posted by
                                            <a href="javascript:void(0);" title=""
                                                >Robin Miles</a
                                            ></span
                                        >
                                        <span class="post-coment thm-bg position-absolute"
                                            ><i class="far fa-comment-dots"></i>03</span
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Blog Wrap -->
                </div>
            </div>
        </section>
    </main>
    <!-- Main Wrapper -->
</template>
