<template>
    <main>
        <section>
            <div class="w-100 position-relative">
                <div class="feat-wrap4 pt-150 pb-140 black-layer position-relative opc3 w-100">
                    <div
                        class="fixed-bg"
                        style="background-image: url(assets/images/resources/feat-bg4.jpg)"
                    ></div>
                    <div class="container">
                        <div class="feat-inner4 pt-240 pb-280 text-center w-100">
                            <span class="d-block"
                                >Find awesome hotel. tour, car and activities in city</span
                            >
                            <h2 class="mb-0">Find Places You Want to Go</h2>
                            <form class="dir-form4 text-left d-flex flex-wrap">
                                <div class="field">
                                    <input type="text" placeholder="What are you looking for" />
                                    <i class="fas fa-search"></i>
                                </div>
                                <div class="field">
                                    <input type="text" placeholder="Event Select" />
                                    <i class="far fa-paper-plane"></i>
                                </div>
                                <div class="field">
                                    <input type="text" placeholder="State, City.." />
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="field-btn">
                                    <button class="thm-btn" type="submit">DISCOVER NOW</button>
                                </div>
                            </form>
                        </div>
                        <!-- Feat Wrap -->
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 overlap310 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">Explore Event</span>
                        <h4 class="mb-0">Popular Caegories Events</h4>
                    </div>
                    <!-- Sec Title -->
                    <div class="city-wrap3 w-100">
                        <div class="row mrg">
                            <div class="col-md-6 col-sm-12 col-lg-5">
                                <div class="city-box3 overflow-hidden position-relative w-100">
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/city-img3-1.jpg"
                                        alt="City Image 1"
                                    />
                                    <div class="city-info3 position-absolute w-100">
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title="">Dinner Events</a>
                                        </h3>
                                        <span class="d-inline-block thm-clr"
                                            ><i class="fas fa-glass-cheers"></i>3 Events
                                            Available</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-lg-5 order-lg-1">
                                <div class="city-box3 overflow-hidden position-relative w-100">
                                    <img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/city-img3-2.jpg"
                                        alt="City Image 2"
                                    />
                                    <div class="city-info3 position-absolute w-100">
                                        <h3 class="mb-0">
                                            <a href="place-listing.html" title="">OutDoor Events</a>
                                        </h3>
                                        <span class="d-inline-block thm-clr"
                                            ><i class="fas fa-glass-cheers"></i>5 Events
                                            Available</span
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-7">
                                <div class="row mrg">
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box3 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img3-3.jpg"
                                                alt="City Image 3"
                                            />
                                            <div class="city-info3 position-absolute w-100">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >Sport Events</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block thm-clr"
                                                    ><i class="fas fa-glass-cheers"></i>8 Events
                                                    Available</span
                                                >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box3 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img3-4.jpg"
                                                alt="City Image 4"
                                            />
                                            <div class="city-info3 position-absolute w-100">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >School Events</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block thm-clr"
                                                    ><i class="fas fa-glass-cheers"></i>2 Events
                                                    Available</span
                                                >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-7">
                                <div class="row mrg">
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box3 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img3-5.jpg"
                                                alt="City Image 5"
                                            />
                                            <div class="city-info3 position-absolute w-100">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >Gym & Health</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block thm-clr"
                                                    ><i class="fas fa-glass-cheers"></i>10 Events
                                                    Available</span
                                                >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                        <div
                                            class="city-box3 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/city-img3-6.jpg"
                                                alt="City Image 6"
                                            />
                                            <div class="city-info3 position-absolute w-100">
                                                <h3 class="mb-0">
                                                    <a href="place-listing.html" title=""
                                                        >Nightlife</a
                                                    >
                                                </h3>
                                                <span class="d-inline-block thm-clr"
                                                    ><i class="fas fa-glass-cheers"></i>2 Events
                                                    Available</span
                                                >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- City Wrap 3 -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-110 position-relative">
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr"
                            >Discover & connect with great local businesses</span
                        >
                        <h2 class="mb-0">See How it Works</h2>
                    </div>
                    <!-- Sec Title -->
                    <div class="how-work-wrap res-row text-center w-100">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="how-work-box w-100">
                                    <span class="rounded-circle d-inline-block"
                                        ><img
                                            class="img-fluid"
                                            src="assets/images/resources/how-work-icon1.png"
                                            alt="How It Works Icon 1"
                                    /></span>
                                    <div class="how-work-inner w-100">
                                        <h3 class="mb-0">Choose what to Do</h3>
                                        <p class="mb-0">
                                            Luxury hotel in the heart of BloomsburyLuxury hotel in
                                            the heart of Bloomsbury..
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="how-work-box w-100">
                                    <span class="rounded-circle d-inline-block"
                                        ><img
                                            class="img-fluid"
                                            src="assets/images/resources/how-work-icon2.png"
                                            alt="How It Works Icon 2"
                                    /></span>
                                    <div class="how-work-inner w-100">
                                        <h3 class="mb-0">Find What You Want</h3>
                                        <p class="mb-0">
                                            Luxury hotel in the heart of BloomsburyLuxury hotel in
                                            the heart of Bloomsbury..
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="how-work-box w-100">
                                    <span class="rounded-circle d-inline-block"
                                        ><img
                                            class="img-fluid"
                                            src="assets/images/resources/how-work-icon3.png"
                                            alt="How It Works Icon 3"
                                    /></span>
                                    <div class="how-work-inner w-100">
                                        <h3 class="mb-0">Amazing Places</h3>
                                        <p class="mb-0">
                                            Luxury hotel in the heart of BloomsburyLuxury hotel in
                                            the heart of Bloomsbury..
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Services Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 gray-layer3 pb-120 opc65 position-relative">
                <div
                    class="fixed-bg patern-bg"
                    style="background-image: url(assets/images/pattern-bg2.png)"
                ></div>
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">You can choose to display featured</span>
                        <h3 class="mb-0">Top Featured Events</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="listing-posts-wrap2 w-100">
                        <div class="listing-post-box3 v3 d-flex flex-wrap w-100">
                            <div class="listing-post-img3">
                                <a href="event-detail.html" title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/list-post-img5-1.jpg"
                                        alt="List Post Image 1"
                                /></a>
                                <span class="position-absolute rounded-pill">Featured</span>
                            </div>
                            <div class="list-post-info3">
                                <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                    <li><i class="thm-clr far fa-clock"></i>May 28, 2018</li>
                                    <li>
                                        <i class="thm-clr fas fa-user-edit"></i>By
                                        <a href="javascript:void(0);">Lokina</a>
                                    </li>
                                </ul>
                                <h3 class="mb-0">
                                    <a href="event-detail.html" title="">New Mexico</a>
                                </h3>
                                <p class="mb-0">
                                    Luxury hotel in the heart of BloomsburyLuxury hotel in the heart
                                    of Bloomsbury Luxury hotel in the heart of BloomsburyLuxury
                                    hotel in the heart of BloomsburyLuxury hotel in the heart
                                </p>
                                <ul class="post-meta d-inline-flex flex-wrap mb-0 list-unstyled">
                                    <li>
                                        <i class="fas fa-glass-cheers rounded-circle"></i>3 Events
                                        Available
                                    </li>
                                    <li>
                                        <i class="fas fa-phone rounded-circle"></i>+61 2 8236 9200
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="listing-post-box3 v3 d-flex flex-wrap w-100">
                            <div class="listing-post-img3">
                                <div class="img-caro">
                                    <div class="caro-img">
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/list-post-img5-2-1.jpg"
                                            alt="List Post Image 2"
                                        />
                                    </div>
                                    <div class="caro-img">
                                        <img
                                            class="img-fluid w-100"
                                            src="assets/images/resources/list-post-img5-2-2.jpg"
                                            alt="List Post Image 2"
                                        />
                                    </div>
                                </div>
                                <span class="position-absolute rounded-pill">Featured</span>
                            </div>
                            <div class="list-post-info3">
                                <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                    <li><i class="thm-clr far fa-clock"></i>May 28, 2018</li>
                                    <li>
                                        <i class="thm-clr fas fa-user-edit"></i>By
                                        <a href="javascript:void(0);">Lokina</a>
                                    </li>
                                </ul>
                                <h3 class="mb-0">
                                    <a href="event-detail.html" title="">Washinton</a>
                                </h3>
                                <p class="mb-0">
                                    Luxury hotel in the heart of BloomsburyLuxury hotel in the heart
                                    of Bloomsbury Luxury hotel in the heart of BloomsburyLuxury
                                    hotel in the heart of BloomsburyLuxury hotel in the heart
                                </p>
                                <ul class="post-meta d-inline-flex flex-wrap mb-0 list-unstyled">
                                    <li>
                                        <i class="fas fa-glass-cheers rounded-circle"></i>3 Events
                                        Available
                                    </li>
                                    <li>
                                        <i class="fas fa-phone rounded-circle"></i>+61 2 8236 9200
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="listing-post-box3 v3 d-flex flex-wrap w-100">
                            <div class="listing-post-img3">
                                <a href="event-detail.html" title=""
                                    ><img
                                        class="img-fluid w-100"
                                        src="assets/images/resources/list-post-img5-3.jpg"
                                        alt="List Post Image 3"
                                /></a>
                                <span class="position-absolute rounded-pill">Featured</span>
                            </div>
                            <div class="list-post-info3">
                                <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                    <li><i class="thm-clr far fa-clock"></i>May 28, 2018</li>
                                    <li>
                                        <i class="thm-clr fas fa-user-edit"></i>By
                                        <a href="javascript:void(0);">Lokina</a>
                                    </li>
                                </ul>
                                <h3 class="mb-0">
                                    <a href="event-detail.html" title="">Colorado</a>
                                </h3>
                                <p class="mb-0">
                                    Luxury hotel in the heart of BloomsburyLuxury hotel in the heart
                                    of Bloomsbury Luxury hotel in the heart of BloomsburyLuxury
                                    hotel in the heart of BloomsburyLuxury hotel in the heart
                                </p>
                                <ul class="post-meta d-inline-flex flex-wrap mb-0 list-unstyled">
                                    <li>
                                        <i class="fas fa-glass-cheers rounded-circle"></i>0 Events
                                        Available
                                    </li>
                                    <li>
                                        <i class="fas fa-phone rounded-circle"></i>+61 2 8236 9200
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="view-all d-inline-block text-center mt-40 w-100">
                        <a class="thm-btn" href="javascript:void(0);" title="">Discover Now</a>
                    </div>
                    <!-- View All -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-180 pb-180 dark-layer2 opc65 position-relative">
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/parallax2.jpg)"
                ></div>
                <div class="container">
                    <div class="video-wrap text-center w-100">
                        <div class="video-inner d-inline-block">
                            <a
                                class="d-inline-block"
                                href="https://www.youtube.com/embed/7EdpBH81XIY"
                                data-fancybox
                                title=""
                                ><i class="fas fa-play"></i
                            ></a>
                            <h2 class="mb-0">Need More Information</h2>
                            <p class="mb-0">
                                Keep calm and get a special discount for all orders over $50 from
                                The Naturel Coffee. Hurry up! Only 3 days left.
                            </p>
                            <a class="thm-btn" href="javascript:void(0);" title="">Explore</a>
                        </div>
                    </div>
                    <!-- Video Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 white-layer pb-100 opc1 position-relative">
                <div
                    class="fixed-bg back-post-cntrtp-norpet"
                    style="background-image: url(assets/images/parallax4.jpg)"
                ></div>
                <div class="container">
                    <div class="sec-title text-center w-100">
                        <span class="d-block thm-clr">We arrange Many other Events</span>
                        <h3 class="mb-0">Most Popular Events</h3>
                    </div>
                    <!-- Sec Title -->
                    <div class="listing-filters w-100">
                        <ul
                            class="fltr-btns mb-0 d-flex flex-wrap justify-content-center list-unstyled w-100"
                        >
                            <li class="active">
                                <a data-filter="*" href="javascript:void(0);" title="">All</a>
                            </li>
                            <li>
                                <a data-filter=".fltr-itm1" href="javascript:void(0);" title=""
                                    >Branding</a
                                >
                            </li>
                            <li>
                                <a data-filter=".fltr-itm2" href="javascript:void(0);" title=""
                                    >UI/UX</a
                                >
                            </li>
                            <li>
                                <a data-filter=".fltr-itm3" href="javascript:void(0);" title=""
                                    >Presentation</a
                                >
                            </li>
                            <li>
                                <a data-filter=".fltr-itm4" href="javascript:void(0);" title=""
                                    >Print</a
                                >
                            </li>
                            <li>
                                <a data-filter=".fltr-itm5" href="javascript:void(0);" title=""
                                    >Web Development</a
                                >
                            </li>
                        </ul>
                        <div class="listing-layout mt-70 w-100">
                            <div class="row masonry">
                                <div class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm1">
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-1.jpg"
                                                alt="List Post Image 1"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm2">
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-2.jpg"
                                                alt="List Post Image 2"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm3">
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-3.jpg"
                                                alt="List Post Image 3"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm4">
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-4.jpg"
                                                alt="List Post Image 4"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm5">
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-5.jpg"
                                                alt="List Post Image 5"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="col-md-6 col-sm-6 col-lg-4 fltr-itm fltr-itm1 fltr-itm2 fltr-itm3 fltr-itm4 fltr-itm5"
                                >
                                    <div class="list-post-box2 position-relative w-100">
                                        <div
                                            class="list-post-img2 overflow-hidden position-relative w-100"
                                        >
                                            <img
                                                class="img-fluid w-100"
                                                src="assets/images/resources/list-post-img2-6.jpg"
                                                alt="List Post Image 6"
                                            />
                                            <span
                                                class="list-post-stats rounded-pill position-absolute"
                                                >Now Closed</span
                                            >
                                            <div
                                                class="list-post-like-rate position-absolute d-flex flex-wrap align-items-center justify-content-between"
                                            >
                                                <a
                                                    class="list-post-like2"
                                                    href="javascript:void(0);"
                                                    title=""
                                                    ><i class="far fa-heart thm-clr"></i>Save</a
                                                ><span class="list-post-rate text-color2"
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><i class="fas fa-star"></i
                                                    ><span>4.5</span></span
                                                >
                                            </div>
                                        </div>
                                        <div class="list-post-info2 w-100">
                                            <ul class="post-meta2 d-inline-flex mb-0 list-unstyled">
                                                <li>
                                                    <i class="thm-clr far fa-clock"></i>May 28, 2018
                                                </li>
                                                <li><i class="thm-clr fas fa-users"></i>50</li>
                                            </ul>
                                            <h3 class="mb-0">
                                                <a href="event-detail2.html" title=""
                                                    >Private Hotel-Spa</a
                                                >
                                            </h3>
                                            <p class="mb-0">Italian traditional served pizzeria.</p>
                                            <ul class="post-meta mb-0 list-unstyled w-100">
                                                <li>
                                                    <i
                                                        class="fas fa-map-marker-alt rounded-circle"
                                                    ></i
                                                    >95 South Park Avenue
                                                </li>
                                                <li>
                                                    <i class="fas fa-phone rounded-circle"></i>+61 2
                                                    8236 9200
                                                </li>
                                            </ul>
                                            <a
                                                class="list-post-event-btn"
                                                href="event-detail2.html"
                                                title=""
                                                >Join Event<i class="fas fa-arrow-right"></i
                                            ></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Listing Layout -->
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pb-100 position-relative">
                <div class="container">
                    <div class="stats-wrap res-row w-100">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="stats-box w-100 d-flex flex-wrap align-items-center">
                                    <div class="stats-prog" id="stats-prog"><span></span></div>
                                    <div class="stats-info">
                                        <h3 class="mb-0">2.1M Events</h3>
                                        <p class="mb-0">
                                            Royal Park of America produces premium branded and
                                            private labela
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="stats-box w-100 d-flex flex-wrap align-items-center">
                                    <div class="stats-prog" id="stats-prog2"><span></span></div>
                                    <div class="stats-info">
                                        <h3 class="mb-0">Statisfaction</h3>
                                        <p class="mb-0">
                                            Royal Park of America produces premium branded and
                                            private labela
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-lg-4">
                                <div class="stats-box w-100 d-flex flex-wrap align-items-center">
                                    <div class="stats-prog" id="stats-prog3"><span></span></div>
                                    <div class="stats-info">
                                        <h3 class="mb-0">20k Daily Events</h3>
                                        <p class="mb-0">
                                            Royal Park of America produces premium branded and
                                            private labela
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Satistics Wrap -->
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-100 pb-80 gray-layer4 opc55 position-relative">
                <div
                    class="fixed-bg"
                    style="background-image: url(assets/images/pattern-bg1.png)"
                ></div>
                <div class="container">
                    <div class="testi-wrap3 text-center w-100">
                        <div class="testi-inner2">
                            <div class="testi-desc-caro3">
                                <div class="testi-desc-item3">
                                    <div class="testi-big-img d-inline-block position-relative">
                                        <img
                                            class="img-fluid rounded-circle"
                                            src="assets/images/resources/testi-big-img1-1.jpg"
                                            alt="Testimonial Big Image 1"
                                        />
                                    </div>
                                    <p class="mb-0">
                                        Curabitur elementum urna augue, eu porta purus gravida in.
                                        Cras consectetur, lorem a cursus vestibulum, ligula purus
                                        iaculis nulla, in dignissim risus turpis id justo. Sed
                                        eleifend ante et ligula eleifend ultricies.
                                    </p>
                                    <h4 class="mb-0 thm-clr">Malujt Looeo</h4>
                                    <span class="d-block">Marketing Envato Pty Ltd.</span>
                                </div>
                                <div class="testi-desc-item3">
                                    <div class="testi-big-img d-inline-block position-relative">
                                        <img
                                            class="img-fluid rounded-circle"
                                            src="assets/images/resources/testi-big-img1-2.jpg"
                                            alt="Testimonial Big Image 2"
                                        />
                                    </div>
                                    <p class="mb-0">
                                        Curabitur elementum urna augue, eu porta purus gravida in.
                                        Cras consectetur, lorem a cursus vestibulum, ligula purus
                                        iaculis nulla, in dignissim risus turpis id justo. Sed
                                        eleifend ante et ligula eleifend ultricies.
                                    </p>
                                    <h4 class="mb-0 thm-clr">Malujt Looeo</h4>
                                    <span class="d-block">Marketing Envato Pty Ltd.</span>
                                </div>
                                <div class="testi-desc-item3">
                                    <div class="testi-big-img d-inline-block position-relative">
                                        <img
                                            class="img-fluid rounded-circle"
                                            src="assets/images/resources/testi-big-img1-3.jpg"
                                            alt="Testimonial Big Image 3"
                                        />
                                    </div>
                                    <p class="mb-0">
                                        Curabitur elementum urna augue, eu porta purus gravida in.
                                        Cras consectetur, lorem a cursus vestibulum, ligula purus
                                        iaculis nulla, in dignissim risus turpis id justo. Sed
                                        eleifend ante et ligula eleifend ultricies.
                                    </p>
                                    <h4 class="mb-0 thm-clr">Malujt Looeo</h4>
                                    <span class="d-block">Marketing Envato Pty Ltd.</span>
                                </div>
                                <div class="testi-desc-item3">
                                    <div class="testi-big-img d-inline-block position-relative">
                                        <img
                                            class="img-fluid rounded-circle"
                                            src="assets/images/resources/testi-big-img1-4.jpg"
                                            alt="Testimonial Big Image 4"
                                        />
                                    </div>
                                    <p class="mb-0">
                                        Curabitur elementum urna augue, eu porta purus gravida in.
                                        Cras consectetur, lorem a cursus vestibulum, ligula purus
                                        iaculis nulla, in dignissim risus turpis id justo. Sed
                                        eleifend ante et ligula eleifend ultricies.
                                    </p>
                                    <h4 class="mb-0 thm-clr">Malujt Looeo</h4>
                                    <span class="d-block">Marketing Envato Pty Ltd.</span>
                                </div>
                            </div>
                            <div class="testi-img-caro3">
                                <div class="testi-img3">
                                    <img
                                        class="img-fluid rounded-circle"
                                        src="assets/images/resources/testi-img3-1.jpg"
                                        alt="Testimonials Image 1"
                                    />
                                </div>
                                <div class="testi-img3">
                                    <img
                                        class="img-fluid rounded-circle"
                                        src="assets/images/resources/testi-img3-2.jpg"
                                        alt="Testimonials Image 2"
                                    />
                                </div>
                                <div class="testi-img3">
                                    <img
                                        class="img-fluid rounded-circle"
                                        src="assets/images/resources/testi-img3-3.jpg"
                                        alt="Testimonials Image 3"
                                    />
                                </div>
                                <div class="testi-img3">
                                    <img
                                        class="img-fluid rounded-circle"
                                        src="assets/images/resources/testi-img3-4.jpg"
                                        alt="Testimonials Image 4"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="w-100 pt-140 pb-140 position-relative">
                <div class="container">
                    <div class="about-toggle-wrap w-100">
                        <div class="row align-items-center">
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <img
                                    class="img-fluid w-100"
                                    src="assets/images/resources/about-img2.jpg"
                                    alt="About Image 2"
                                />
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-6">
                                <div class="toggle w-100" id="toggle">
                                    <div class="toggle-item w-100">
                                        <h4 class="mb-0">
                                            Royal Park of America Produces<i class=""></i>
                                        </h4>
                                        <div class="toggle-content w-100">
                                            <p class="mb-0">
                                                Royal Park of America produces premium branded and
                                                private label lubricants for agriculture.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="toggle-item w-100">
                                        <h4 class="mb-0">
                                            Private label Lubricants<i class=""></i>
                                        </h4>
                                        <div class="toggle-content w-100">
                                            <p class="mb-0">
                                                Royal Park of America produces premium branded and
                                                private label lubricants for agriculture.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="toggle-item w-100">
                                        <h4 class="mb-0">Automotive, Fleet<i class=""></i></h4>
                                        <div class="toggle-content w-100">
                                            <p class="mb-0">
                                                Royal Park of America produces premium branded and
                                                private label lubricants for agriculture.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="toggle-item w-100">
                                        <h4 class="mb-0">
                                            industrial Applications.<i class=""></i>
                                        </h4>
                                        <div class="toggle-content w-100">
                                            <p class="mb-0">
                                                Royal Park of America produces premium branded and
                                                private label lubricants for agriculture.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- About Toggle Wrap -->
                </div>
            </div>
        </section>
    </main>
    <!-- Main Wrapper -->
</template>
